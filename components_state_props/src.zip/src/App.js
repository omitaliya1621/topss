import logo from './logo.svg';
import '../node_modules/bootstrap/dist/css/bootstrap.css'
import FunctionComponents from './FunctionComponents';
import ClassComponents from './ClassComponents';
import CardFormate from './CardFormate';
import Countercomponent from './Countercomponent ';

function App() {
  const arr=[
    {id:1, src:"https://picsum.photos/100/100?1",name:"om",age:21,address:"Bhavnagar"},
    {id:2, src:"https://picsum.photos/100/100?2",name:"Harmit",age:22,address:"Surat"},
    {id:3, src:"https://picsum.photos/100/100?3",name:"Jay",age:23,address:"Ahmedabad"},
    {id:4, src:"https://picsum.photos/100/100?4",name:"Namik",age:24,address:"Vapi"},
    {id:5, src:"https://picsum.photos/100/100?5",name:"Harshil",age:25,address:"Bardoli"},
  ]
  return (
    <div className="App">
      <FunctionComponents nm="om"/>
      <ClassComponents/>
      <CardFormate nmm={arr}/>
      <Countercomponent/>
    </div>
  );
}

export default App;
