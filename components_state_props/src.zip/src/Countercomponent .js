import React, { useState } from 'react'

export default function Countercomponent() {
    const [number, setnumber] = useState(0)
    return (
        <>
            <div className='fs-1'>Countercomponent </div>
            <div className='mx-5'>
                <button onClick={((v) => { setnumber(number+1) })} className='btn btn-success'>+</button>
                <h2>{number}</h2>
                <button onClick={((v) => { setnumber(number-1) })} className='btn btn-danger'>-</button>

            </div>
        </>
    )
}
