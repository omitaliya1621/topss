import React from 'react'

export default function CardFormate({ nmm }) {
    return (
        <>
            <div className='fs-3'>CardFormate</div>
            <div className='d-flex gap-5'>
            {nmm.map((v) => {
                return (
                    <div className=' border border-3 p-4'>
                        <img className="d-inline"src={v.src}></img>
                        <h5>{v.name}</h5>
                        <p>{v.age}</p>
                        <p>{v.address}</p>
                    </div>
                )
            })}
            </div>
            <hr></hr>
            
        </>
    )
}
