import React, { Component } from 'react'

export default class ClassComponents extends Component {
  render() {
    return (
        <>
        <hr></hr>
      <h1 className='fs-1'>ClassComponents</h1>
      <div className='fs-4'>"Welcome to React!</div>
      <hr></hr>
      </>

    )
  }
}
