import React from 'react'
// import '../node_modules./react'
function FunctionComponents(props) {
  return (
    <>
    <h1>FunctionComponents</h1>
    <div className='fs-1'>"Hello,{props.nm}"</div>
    </>
  )
}

export default FunctionComponents