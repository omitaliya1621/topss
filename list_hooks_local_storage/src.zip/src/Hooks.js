import React, { useEffect, useState } from 'react'
// import { useSelector, useDispatch } from "react-redux";x
function Hooks() {
    const[number,setnumber]= useState(0)
  return (
    < >
    <div className='p-4 '>
    <p className='fs-4 text-bold'>Hooks</p>
    <p className='fs-4 text-bold'>Q-1</p>
    <p className='ps-5 ms-4'>{number}</p>
    <button className="btn btn-success me-2"onClick={()=>{setnumber(number+1)}}>Increment</button>
    <button className="btn btn-danger" onClick={()=>{setnumber(number-1)}}>Decrement</button>
    </div>
    <UserList />
    {/* <UserLis/>//q-3 */}
    </>
  )
}

    const UserList = () => {
        const [users, setUsers] = useState([]);
      
        useEffect(() => {
          fetch("https://jsonplaceholder.typicode.com/users")
            .then((response) => response.json())
            .then((data) => setUsers(data))
        }, []);
      
        return (
          <div className="p-4">
            <p className='fs-4'>Q-2</p>
            <h2 className="text-xl font-bold mb-2">User List</h2>
            <ul className="list-disc pl-5">
              {users.map((user) => (
                <li key={user.id} className="text-lg">{user.name}</li>
              ))}
            </ul>
          </div>
        );
      };

    //   const UserLis = () => {
    //     const dispatch = useDispatch();
    //     const users = useSelector((state) => state.users);
      
    //     useEffect(() => {
    //       dispatch(fetchUsers());
    //     }, [dispatch]);
      
    //     return (
    //       <div className="p-4">
    //         <h2 className="text-xl font-bold mb-2">User List</h2>
    //         <ul className="list-disc pl-5">
    //           {users.map((user) => (
    //             <li key={user.id} className="text-lg text-gray-700">{user.name}</li>
    //           ))}
    //         </ul>
    //       </div>
    //     );
    //   };

export default Hooks