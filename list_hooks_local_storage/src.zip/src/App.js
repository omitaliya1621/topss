import logo from './logo.svg';
import './App.css';
import List from './List';
import Uniqekey from './Uniqekey';
import Hooks from './Hooks';

function App() {
  const users = [{ id: 1, name: "OM" }, { id: 2, name: "Harmit" }, { id: 3, name: "Jenil" }, { id: 4, name: "Manan" }, { id: 5, name: "Smit" }];
  return (
<>
<List/>
<Uniqekey users={users}/>
<Hooks/>
</>
  )
}

export default App;
