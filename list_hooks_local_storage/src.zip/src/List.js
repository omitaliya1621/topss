import React, { Component } from 'react'

export default class List extends Component {
    render() {
        const fruits = ["Apple", "Banana", "Cherry", "Mango", "Orange"];
        return (
            <>
                <div className="p-4">
                    <h2 className="text-xl font-bold mb-2">Fruit List</h2>
                    <ul className="list-disc pl-5">
                        {fruits.map((v, i) => {
                            return (<li key={i} style={{ color: (i % 2 == 0) ? "red" : "green" }}>{v}</li>)
                        })}
                    </ul>
                </div>
            </>
        )
    }
}
