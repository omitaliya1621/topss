import React, { Component } from 'react'

export default class Uniqekey extends Component {
    render() {
        
        return (
            <>
                <div className="p-4">
                    <b className="font-bold mb-2 ">• Create a list of users where each user has a unique id. Render the user list
                        usingReact and assign a unique keyto each user.
                    </b>
                    <ul className="list-disc pl-5">
                        {this.props.users.map((user) => (
                            <li key={user.id} className="text-lg ">{user.name}</li>
                        ))}
                    </ul>
                </div>
            </>
        )
    }
}
