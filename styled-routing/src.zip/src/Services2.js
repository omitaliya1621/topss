import React from 'react'

function Services2() {
  return (
    <div><h1>This Is A Services 2 Page</h1></div>
  )
}

export default Services2