import React from 'react'
import { Link, Outlet } from 'react-router-dom'

function Services() {
  return (
    <div><h1>This Is A Services Page</h1>
    
<div>
        
            <ul className='list-unstyled'>
            <li>
                <Link  className='btn btn-primary text-white mb-2' to="services1">Services 1</Link>
            </li>
            <li>
                <Link className='btn btn-primary text-white' to="services2">Services 2</Link>
            </li>
            </ul>
</div>
        
     <Outlet />
    </div>
  )
}

export default Services