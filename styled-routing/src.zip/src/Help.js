import React from 'react'

function Help() {
  return (
    <div><h1>This Is A Help Page</h1></div>
  )
}

export default Help