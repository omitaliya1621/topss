import logo from './logo.svg';
// import './App.css';
import {BrowserRouter, Routes, Route, Link} from 'react-router-dom';
import '../node_modules/bootstrap/dist/css/bootstrap.css';
import '../node_modules/bootstrap/dist/js/bootstrap.js';
import Home from './Home.js';
import About from './About.js';
import Services from './Services.js';
import Help from './Help.js';
import Services1 from './Services1.js';
import Services2 from './Services2.js';

function App() {
  return (
    <div className="">
     <BrowserRouter>
     
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container-fluid">
          
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link className=" btn btn-info" to="/">Home</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/about">About</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/services">Services</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/help">Help</Link>
              </li>
            </ul>
          </div>
        </div>
        </nav>
     <Routes>
        
          <Route path="/" element={<Home/>} />
          <Route path="/about" element={<About/>}/>
          <Route path="/services" element={<Services/>}>
            <Route path="/services/services1" element={<Services1/>}/>
            <Route path="/services/services2" element={<Services2/>}/>
          </Route>
          <Route path="/help" element={<Help/>}/>
      
     </Routes>
     </BrowserRouter>
    </div>
  );
}

export default App;
