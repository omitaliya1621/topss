import  { useState } from 'react'
import { Bounce, toast } from 'react-toastify'

function UseCustomhook() {
    const [email, setemail] = useState('')
    const [password, setpassword] = useState('')
    const [repassword, setrepassword] = useState('')
    const [fname, setfname] = useState('')
    const [lname, setlname] = useState('')
    const [phon, setphon] = useState('')
    const [address, setaddress] = useState('')
    const [region, setregion] = useState('')
    const [pincode, setpincode] = useState('')
    const [country, setcountry] = useState('')

    const check = () => {
        if (email === '' || password === '' || repassword === '' || fname === '' || lname === '' || phon === '' || pincode === '' || region === '' || address === '' || country === '') {
            toast.error('Please fill all fields', {
                position: "top-center",
                autoClose: 2500,
                hideProgressBar: false,
                closeOnClick: false,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "colored",
                transition: Bounce,
            });
            
           
        } 
        else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            toast.error('Enter a valid Email', {
                position: "top-center",
                autoClose: 2500,
                hideProgressBar: false,
                closeOnClick: false,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "colored",
                transition: Bounce,
            });
        } 
        else if (password !== repassword) {
            toast.error('Passwords do not match', {
                position: "top-center",
                autoClose: 2500,
                hideProgressBar: false,
                closeOnClick: false,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "colored",
                transition: Bounce,
            });
        }
        else if (!/^\+?[1-9]\d{1,14}$/.test(phon)) {
            toast.error('Please valid number', {
                position: "top-center",
                autoClose: 2500,
                hideProgressBar: false,
                closeOnClick: false,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "colored",
                transition: Bounce,
            });
        }
        else if (fname.length < 4) {
            toast.error('Name must be at least 4 characters', {
                position: "top-center",
                autoClose: 2500,
                hideProgressBar: false,
                closeOnClick: false,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "colored",
                transition: Bounce,
            });
        }
        
        
        
        else{
            toast.success('data add successfully', {
                position: "top-center",
                autoClose: 2500,
                hideProgressBar: false,
                closeOnClick: false,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "colored",
                transition: Bounce,
                });
                setemail('');
                setpassword('');
                setrepassword('');
                setfname('');
                setlname('');
                setphon('');
                setaddress('');
                setregion('');
                setpincode('');
                setcountry('');

        }
    }

    return [email, setemail, password, setpassword, repassword, setrepassword, fname, setfname, lname, setlname, phon, setphon, address, setaddress, region, setregion, pincode, setpincode, country, setcountry, check]
}

export default UseCustomhook;
