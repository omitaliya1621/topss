import React from 'react';
import UseCustomhook from './Customhook';
import { ToastContainer } from 'react-toastify';
import 'bootstrap/dist/css/bootstrap.min.css';

function RegistrationForm() {
  const [email, setemail, password, setpassword, repassword, setrepassword, fname, setfname, lname, setlname, phon, setphon, address, setaddress, region, setregion, pincode, setpincode, country, setcountry, check] = UseCustomhook();

  return (
    <>
      <div className="container mt-4">
        <h2 className="text-center">Registration Form</h2>
        <p className="text-center text-muted">Fields marked * are required</p>
        <form className="card p-4 shadow-sm mx-auto" style={{ maxWidth: '600px' }}>
          <div className="mb-3">
            <label className="form-label">Email *</label>
            <input value={email} onChange={(e) => setemail(e.target.value)} type="email" className="form-control" required />
          </div>
          <div className="mb-3">
            <label className="form-label">Password *</label>
            <input value={password} onChange={(e) => setpassword(e.target.value)} type="password" className="form-control" required />
          </div>
          <div className="mb-3">
            <label className="form-label">Retype Password *</label>
            <input value={repassword} onChange={(e) => setrepassword(e.target.value)} type="password" className="form-control" required />
          </div>
          <div className="row">
            <div className="col-md-6 mb-3">
              <label className="form-label">First Name *</label>
              <input value={fname} onChange={(e) => setfname(e.target.value)} type="text" className="form-control" required />
            </div>
            <div className="col-md-6 mb-3">
              <label className="form-label">Last Name *</label>
              <input value={lname} onChange={(e) => setlname(e.target.value)} type="text" className="form-control" required />
            </div>
          </div>
          <div className="mb-3">
            <label className="form-label">Phone Number *</label>
            <input value={phon} onChange={(e) => setphon(e.target.value)} type="text" className="form-control" required />
          </div>
          <div className="mb-3">
            <label className="form-label">Address *</label>
            <input value={address} onChange={(e) => setaddress(e.target.value)} type="text" className="form-control" required />
          </div>
          <div className="row">
            <div className="col-md-6 mb-3">
              <label className="form-label">Region *</label>
              <input value={region} onChange={(e) => setregion(e.target.value)} type="text" className="form-control" required />
            </div>
            <div className="col-md-6 mb-3">
              <label className="form-label">Postcode / Zip *</label>
              <input value={pincode} onChange={(e) => setpincode(e.target.value)} type="text" className="form-control" required />
            </div>
          </div>
          <div className="mb-3">
            <label className="form-label">Country *</label>
            <select value={country} onChange={(e) => setcountry(e.target.value)} className="form-control" required>
              <option hidden>Select Country</option>
              <option value="USA">United States</option>
              <option value="Canada">Canada</option>
              <option value="India">India</option>
              <option value="UK">United Kingdom</option>
              <option value="Australia">Australia</option>
            </select>
          </div>
          <button type="button" onClick={check} className="btn btn-primary w-100">Register</button>
        </form>
      </div>
      <ToastContainer />
    </>
  );
}

export default RegistrationForm;
