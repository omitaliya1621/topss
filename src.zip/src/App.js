import './App.css';
import RegistrationForm from './RegistrationForm';
import '../node_modules/bootstrap/dist/css/bootstrap.css';
function App() {
  return (
    <div>
   <RegistrationForm/>
    </div>
  );
}

export default App;
